from metodos_ordenamiento import (
    burbuja,
    heapsort,
    insercion,
    quicksort,
    radix,
    seleccion,
    shellsort,
)

# Lista de ejemplo para ordenar
arr = [170, 45, 75, 90, 802, 24, 2, 66]

print("\n=== Resultados de Ordenamiento ===")
print(f"Original:  {arr}")

# Aseguramos que cada llamada use una copia para no afectar la lista original
print(f"\nBurbuja:   {burbuja(arr.copy())}")
print(f"inserción: {insercion(arr.copy())}")
print(f"seleccion: {seleccion(arr.copy())}")
print(f"shellSort: {shellsort(arr.copy())}")
print(f"quicksort: {quicksort(arr.copy())}")
print(f"heapsort:  {heapsort(arr.copy())}")
print(f"radix:     {radix(arr.copy())}")