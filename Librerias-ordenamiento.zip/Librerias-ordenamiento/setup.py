from setuptools import setup, find_packages

setup(
    name="metodos_ordenamiento",
    version="1.0.0",
    packages=find_packages(),
    description="Paquete con métodos de ordenamiento",
)